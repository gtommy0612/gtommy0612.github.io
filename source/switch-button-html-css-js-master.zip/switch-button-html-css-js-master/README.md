# switch-button-html-css-js
 Smooth switch button use only HTML, CSS, Javascript

![alt text](https://raw.githubusercontent.com/trananhtuat/switch-button-html-css-js/master/demo.jpg)